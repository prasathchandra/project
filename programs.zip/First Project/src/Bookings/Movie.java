package Bookings;

import java.util.Scanner;

public class Movie {
	                 private String name;
 	                 private String theatername;
	                 private int nooftickets;
                     private int cost;
                     
                     Movie(){
                    	 
                    	 Scanner sc = new Scanner(System.in);
                    	 System.out.println("Enter the Name of the Movie: ");
                    	 this.name = sc.nextLine();
                    	 System.out.println("Enter the Theater Name: ");
                    	 this.theatername = sc.nextLine();
                    	 System.out.println("Enter the No.of.Tickets:");
                    	 this.nooftickets = sc.nextInt();
                    	 System.out.println("Enter the Cost per Ticket: ");
                    	 this.cost = sc.nextInt();
                     }  
                     void setNmae(String name) {
                    	 
                    	 this.name = name;
                     }
                     String getName() {
                    	 
                    	 return name;
                     }
                     void settheatername(String theatername) {
                    	 
                    	 this.theatername = theatername;
                     }
                     String gettheatername() {
                    	 
                    	 return theatername;
                     }
                     void setnooftickets(int nooftickets) {
                    	 
                    	 this.nooftickets = nooftickets;
                     }
                     int getnooftickets() {
                    	 
                    	 return nooftickets;
                     }
                     void setcost(int cost) {
                    	 
                    	 this.cost = cost;
                     }
                     int getcost() {
                    	 
                    	 return cost;
                     }
                     
                     void storeAllDetails(String name,String brand,int memory,int camera,double price)
                     {
                    	 this.name = name;
                    	 this.theatername = theatername;
                    	 this.nooftickets = nooftickets;
                    	 this.cost = cost;
                     }
                     
                     void viewAllDetails() {
                    	 
                    	 System.out.println("Name :" +name);
                    	 System.out.println("Theater Name :" +theatername);
                    	 System.out.println("Nof.of.Tickets :" +nooftickets);
                    	 System.out.println("Cost of the Ticket : " +cost);
                    	 
                     }
                     


                      





}
